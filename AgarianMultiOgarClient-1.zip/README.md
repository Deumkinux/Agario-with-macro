# Agarian-2.github.io
An experimental client for my MultiOgar server.

Basic Information:
 - This client can be used for most MultiOgar-based servers.
 - Has working skins.
 - This client is NOT originally made by me, only modified.
 - Occasional consistent updates.
 - This client works best with my MultiOgar server, located at https://github.com/agarian-2/MultiOgar.
 
Credits:
- The original CigarProject, https://github.com/CigarProject/Cigar.
- The base code, https://github.com/Luka967/Cigar.
- Where some recent features came from, https://github.com/Cigar2/Cigar2.

What's new (mostly options):
 - A major amount of game customization.
 - More detailed minimap.
 - More detailed server stats.
 - Some 'important' links for you to check out.
 - Adjusted leaderboard (looks much more like agar.io's leaderboard).
 - Hundreds of skins.
 - Sounds.
 - A lot of other minor changes, improvements, and fixes.
